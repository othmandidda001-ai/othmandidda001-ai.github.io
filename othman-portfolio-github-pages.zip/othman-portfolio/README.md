# Othman Didda — Portfolio

A bilingual English/French portfolio built with HTML, CSS, and vanilla JavaScript. Designed for GitHub Pages and does not require a database, backend, build step, or package manager.

## Live site

When GitHub Pages is enabled for this repository, the site should be available at:

https://othmandidda001-ai.github.io/

## Files

- `index.html` — portfolio homepage and sections
- `project.html` — reusable individual project detail template
- `404.html` — custom not-found page
- `assets/css/styles.css` — design system and responsive styling
- `assets/images/` — profile and project images
- `js/translations.js` — English and French UI text
- `js/projects.js` — project catalogue and detail content
- `js/main.js` — navigation, language switching, filters, search, and UI behavior
- `js/project-detail.js` — project detail rendering
- `favicon.svg` — browser icon

## Publish with GitHub Pages

1. Open the repository `othmandidda001-ai.github.io`.
2. Upload or create all files and folders at the repository root, preserving the structure above.
3. Commit the changes to the `main` branch.
4. Open **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then save.
7. Wait for GitHub Pages to finish deploying.
8. Visit https://othmandidda001-ai.github.io/.

The first deployment may take a few minutes. Check the **Actions** tab if the site does not publish.

## Customize your information before publishing

Search the repository for `YOUR_EMAIL@example.com` and replace it with the public contact email you want to use. Update the email links and the `data-email` value on the copy-email button together.

Update LinkedIn placeholders if you add a LinkedIn link. The current website does not invent a profile URL.

Add your profile photo to `assets/images/` and update the hero section in `index.html` if you want a real photo. The current hero uses a CSS-generated illustration. `assets/images/profile-placeholder.svg` is an optional placeholder asset.

Review the professional experience dates and company name before publishing. The current six-month experience has intentionally marked dates/company as needing confirmation. Make sure every tool listed is something you have actually used or studied.

## Add a new project

Open `js/projects.js` and add another object inside `window.PORTFOLIO_PROJECTS`. Follow the existing objects as a template. Required fields:

- `slug`: unique URL-safe identifier, for example `network-monitoring-lab`
- `category`: one of `cybersecurity`, `systems`, `virtualization`, or `networks`
- `statusKey`: one of `statusLab`, `statusAcademic`, or `statusPlanned`
- `title`: object with `en` and `fr`
- `summary`: object with `en` and `fr`
- `technologies`: array of technology names
- `objective`, `architecture`, `implementation`, `challenges`, `security`, `results`: translated content

Then commit the change. The project card will link to:

`project.html?slug=network-monitoring-lab`

This is a static website. Project edits happen in the repository; there is no private admin dashboard or database.

## Add project screenshots

1. Create a folder such as `assets/images/projects/`.
2. Upload compressed PNG, JPG, or WebP images.
3. Add an image reference to your project data and update the project template if you want to display screenshots.
4. Remove personal information, hostnames, public IPs, credentials, and confidential organization details before uploading.

## Language

The language switcher uses `js/translations.js`; project-specific text is stored bilingually in `js/projects.js`. Add or update both `en` and `fr` values for new content.

## Before going live

- Replace the email placeholder.
- Confirm experience dates and company details.
- Verify education and certification details.
- Review every project description; sample content is a starting point and must match actual implementation.
- Add a real profile photo if desired.
- Test mobile navigation, project filters, search, French/English switching, and project detail links.
- Test the published site URL and inspect browser developer tools for errors.

## Privacy and security

Do not commit passwords, tokens, API keys, private keys, or other secrets. Do not publish sensitive lab screenshots or private infrastructure details. This site does not have authentication or a server-side contact form.
