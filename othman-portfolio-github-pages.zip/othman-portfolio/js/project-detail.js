(function(){
  "use strict";
  const root=document.getElementById("project-detail");
  const translations=window.PORTFOLIO_TRANSLATIONS||{};
  let language="en";
  try{language=localStorage.getItem("portfolio-language")==="fr"?"fr":"en"}catch(_){}
  const t=key=>(translations[language]||translations.en||{})[key]||key;
  const safe=value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const list=value=>Array.isArray(value)?value.map(v=>`<li>${safe(v)}</li>`).join(""):`<li>${safe(value||"")}</li>`;
  function render(){
    if(!root)return;
    const slug=new URLSearchParams(location.search).get("slug");
    const p=(window.PORTFOLIO_PROJECTS||[]).find(item=>item.slug===slug);
    if(!p){document.title=t("projectNotFound")+" | Othman Didda";root.innerHTML=`<div class="detail-hero"><p class="section-kicker">404 / PROJECT</p><h1>${safe(t("projectNotFound"))}</h1><p>${safe(t("projectNotFoundDesc"))}</p><a class="button button-primary" href="index.html#projects">${safe(t("backToPortfolio"))} ↗</a></div>`;return}
    const title=p.title?.[language]||p.title?.en||"Project";
    const summary=p.summary?.[language]||p.summary?.en||"";
    document.title=title+" | Othman Didda";
    const cat=t(({cybersecurity:"filterCyber",systems:"filterSystems",virtualization:"filterVirtual",networks:"filterNetworks"})[p.category]||"filterAll");
    const section=(heading,content)=>`<section><h2>${safe(t(heading))}</h2>${Array.isArray(content)?`<ul>${list(content)}</ul>`:`<p>${safe(content||"")}</p>`}</section>`;
    root.innerHTML=`<div class="detail-hero"><p class="section-kicker">${safe(cat)} / TECHNICAL PROJECT</p><h1>${safe(title)}</h1><p>${safe(summary)}</p><div class="detail-tags">${(p.technologies||[]).map(x=>`<span class="tech-pill">${safe(x)}</span>`).join("")}</div></div><div class="detail-content"><div class="detail-sections">${section("detailObjective",p.objective?.[language]||p.objective?.en)}${section("detailArchitecture",p.architecture?.[language]||p.architecture?.en)}${section("detailImplementation",p.implementation?.[language]||p.implementation?.en)}${section("detailChallenges",p.challenges?.[language]||p.challenges?.en)}${section("detailSecurity",p.security?.[language]||p.security?.en)}${section("detailResults",p.results?.[language]||p.results?.en)}<p class="project-disclaimer">${safe(t("detailDisclaimer"))}</p><a class="text-link" href="index.html#projects">${safe(t("backProjects"))} →</a></div><aside class="detail-aside"><h3>${safe(t("detailTechnologies"))}</h3><div class="tag-list">${(p.technologies||[]).map(x=>`<span>${safe(x)}</span>`).join("")}</div><h3 style="margin-top:24px">${safe(t("detailCategory"))}</h3><p>${safe(cat)}</p><h3>${safe(t("detailStatus"))}</h3><p>${safe(t(p.statusKey||"statusLab"))}</p></aside></div>`;
  }
  document.getElementById("language-toggle")?.addEventListener("click",()=>{language=language==="en"?"fr":"en";try{localStorage.setItem("portfolio-language",language)}catch(_){}document.documentElement.lang=language;document.getElementById("language-toggle").textContent=language==="en"?"FR":"EN";document.querySelectorAll("[data-i18n]").forEach(el=>{el.innerHTML=t(el.dataset.i18n)});render()});
  document.getElementById("year")&&(document.getElementById("year").textContent=new Date().getFullYear());
  document.addEventListener("DOMContentLoaded",render);render();
})();