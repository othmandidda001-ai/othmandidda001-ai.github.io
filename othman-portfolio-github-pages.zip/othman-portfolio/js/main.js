(function(){
  "use strict";
  document.documentElement.classList.add("js-ready");
  const translations=window.PORTFOLIO_TRANSLATIONS||{};
  let language="en";
  try{language=localStorage.getItem("portfolio-language")==="fr"?"fr":"en"}catch(_){}
  const t=(key)=>((translations[language]||translations.en||{})[key]||key);
  function setLanguage(lang){
    language=lang==="fr"?"fr":"en";
    document.documentElement.lang=language;
    document.querySelectorAll("[data-i18n]").forEach(el=>{
      const value=t(el.dataset.i18n);
      if(value!==el.dataset.i18n) el.innerHTML=value;
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{el.placeholder=t(el.dataset.i18nPlaceholder)});
    const toggle=document.getElementById("language-toggle");
    if(toggle){toggle.textContent=language==="en"?"FR":"EN";toggle.setAttribute("aria-label",language==="en"?"Passer en français":"Switch to English")}
    try{localStorage.setItem("portfolio-language",language)}catch(_){}
    renderProjects();
    document.dispatchEvent(new CustomEvent("portfolio:languagechange",{detail:{language}}));
  }
  const grid=document.getElementById("projects-grid");
  const filters=document.getElementById("project-filters");
  const search=document.getElementById("project-search");
  let activeFilter="all";
  function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
  function renderProjects(){
    if(!grid)return;
    const projects=window.PORTFOLIO_PROJECTS||[];
    const query=(search?.value||"").trim().toLowerCase();
    const shown=projects.filter(p=>(activeFilter==="all"||p.category===activeFilter)&&
      [p.title?.[language],p.summary?.[language],...(p.technologies||[])].join(" ").toLowerCase().includes(query));
    if(!shown.length){grid.innerHTML='<p class="empty-state">'+esc(t("noProjects"))+'</p>';return}
    grid.innerHTML=shown.map(p=>{
      const title=p.title?.[language]||p.title?.en||"Project";
      const summary=p.summary?.[language]||p.summary?.en||"";
      const categoryLabel=t(({cybersecurity:"filterCyber",systems:"filterSystems",virtualization:"filterVirtual",networks:"filterNetworks"})[p.category]||"filterAll");
      const tags=(p.technologies||[]).slice(0,4).map(x=>`<span>${esc(x)}</span>`).join("");
      return `<article class="project-card"><div class="project-art ${esc(p.category)}"><span class="art-symbol" aria-hidden="true">${p.category==="cybersecurity"?"⌘":p.category==="systems"?"▣":p.category==="networks"?"⌁":"◈"}</span><span class="art-caption">OD / TECHNICAL LAB</span></div><div class="project-body"><div class="project-meta"><span class="project-category">${esc(categoryLabel)}</span><span class="project-status">${esc(t(p.statusKey||"statusLab"))}</span></div><h3>${esc(title)}</h3><p>${esc(summary)}</p><div class="tag-list">${tags}</div><a class="project-link" href="project.html?slug=${encodeURIComponent(p.slug)}"><span>${esc(t("viewDetails"))}</span><span aria-hidden="true">↗</span></a></div></article>`;
    }).join("");
  }
  document.getElementById("language-toggle")?.addEventListener("click",()=>setLanguage(language==="en"?"fr":"en"));
  document.getElementById("menu-toggle")?.addEventListener("click",()=>{
    const button=document.getElementById("menu-toggle"),links=document.getElementById("nav-links");
    const open=button.getAttribute("aria-expanded")!=="true";
    button.setAttribute("aria-expanded",String(open));button.setAttribute("aria-label",open?"Close navigation":"Open navigation");links.classList.toggle("open",open);
  });
  document.querySelectorAll("#nav-links a").forEach(a=>a.addEventListener("click",()=>{
    document.getElementById("nav-links")?.classList.remove("open");
    document.getElementById("menu-toggle")?.setAttribute("aria-expanded","false");
  }));
  document.addEventListener("keydown",e=>{if(e.key==="Escape"){document.getElementById("nav-links")?.classList.remove("open");document.getElementById("menu-toggle")?.setAttribute("aria-expanded","false")}});
  filters?.addEventListener("click",e=>{
    const button=e.target.closest("[data-filter]");if(!button)return;
    activeFilter=button.dataset.filter;
    filters.querySelectorAll("[data-filter]").forEach(b=>b.classList.toggle("active",b===button));
    renderProjects();
  });
  search?.addEventListener("input",renderProjects);
  document.getElementById("copy-email")?.addEventListener("click",async e=>{
    const button=e.currentTarget,email=button.dataset.email,feedback=document.getElementById("copy-feedback");
    if(!email||email.includes("YOUR_EMAIL")){feedback.textContent=t("emailPlaceholder");return}
    try{await navigator.clipboard.writeText(email);feedback.textContent=t("emailCopied")}
    catch(_){feedback.textContent=email}
  });
  document.getElementById("year")&&(document.getElementById("year").textContent=new Date().getFullYear());
  const observer=("IntersectionObserver" in window)?new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("is-visible");observer.unobserve(entry.target)}}),{threshold:.12}):null;
  document.querySelectorAll(".reveal").forEach(el=>observer?observer.observe(el):el.classList.add("is-visible"));
  if("IntersectionObserver" in window){
    const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
      if(entry.isIntersecting){document.querySelectorAll('.nav-links a[href^="#"]').forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+entry.target.id))}
    }),{rootMargin:"-35% 0px -55% 0px"});
    document.querySelectorAll("main section[id]").forEach(s=>sectionObserver.observe(s));
  }
  setLanguage(language);
})();